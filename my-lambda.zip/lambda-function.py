import boto3

def lambda_handler(event, context):
    if 'detail' in event and 'eventName' in event['detail'] and event['detail']['eventName'] == 'StartInstances':
        instance_id = event['detail']['requestParameters']['instancesSet']['items'][0]['instanceId']
        if instance_id == 'your_ec2_instance_id':
            if check_docker_image_pull_success(instance_id):
                send_sns_notification()


def check_docker_image_pull_success(instance_id):
    log_group_name = '/var/log/docker.log'
    log_stream_name = instance_id
    logs_client = boto3.client('logs')
    response = logs_client.filter_log_events(
        logGroupName=log_group_name,
        logStreamNames=[log_stream_name],
        filterPattern='Image pull complete'
    )

    if response['events']:
        return True
    else:
        return False


def send_sns_notification():
    sns_topic_arn = 'your_sns_topic_arn'
    sns_client = boto3.client('sns')
    subject = 'EC2 Docker Image Pull Successful'
    message = 'The EC2 instance has successfully pulled a Docker image from the DockerHub repository.'

    response = sns_client.publish(
        TopicArn=sns_topic_arn,
        Message=message,
        Subject=subject
    )
    print("SNS Notification Sent: {}".format(response))
